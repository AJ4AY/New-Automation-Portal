package com.PortalDB;

public class TestSuite {

    private int id;
    private int test_case_id;
    private int test_tool_id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTest_case_id() {
        return test_case_id;
    }

    public void setTest_case_id(int test_case_id) {
        this.test_case_id = test_case_id;
    }

    public int getTest_tool_id() {
        return test_tool_id;
    }

    public void setTest_tool_id(int test_tool_id) {
        this.test_tool_id = test_tool_id;
    }
}
