package com.PortalDB;

import org.junit.runner.JUnitCore;

public class Runner {

    public static void main(String[] args) {

        JUnitCore junit = new JUnitCore();
        junit.run(UpdateTestRun.class);

    }

}
