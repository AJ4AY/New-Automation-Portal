package portal.services;


public interface AdminService {
	
	void resetStatisticsToZero();
}
