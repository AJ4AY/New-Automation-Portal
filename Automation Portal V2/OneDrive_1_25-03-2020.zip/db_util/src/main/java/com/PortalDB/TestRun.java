package com.PortalDB;

public class TestRun {

    private int test_suite_id;
    private int test_case_id;

    public int getTest_case_id() {
        return test_case_id;
    }

    public void setTest_case_id(int test_case_id) {
        this.test_case_id = test_case_id;
    }
}
