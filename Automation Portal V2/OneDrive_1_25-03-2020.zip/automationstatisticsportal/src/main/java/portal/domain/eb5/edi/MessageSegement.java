package portal.domain.eb5.edi;

public final class MessageSegement {
	public static int messageSegmentCount;
}
